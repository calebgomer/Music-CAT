Google-Play-Music-Extension
===========================

Adds easy dropdown controls and keyboard shortcuts to Google Play Music.

Works with All Access.
